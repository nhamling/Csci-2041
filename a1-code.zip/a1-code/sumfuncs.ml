let array_sum arr =
	let len = Array.length arr in
	let sum = ref 0 in
	for i=0 to len-1 do 
		let next = !sum + arr.(i) in
		sum := next;
	done;
	!sum
;;	

let rec list_sum lst =
	if lst = [] then 					 (*Base Case*)
		0
	else								 (*Recursive Step*)
		let first = List.hd lst in		 
		let rest = List.tl lst in
		let sum_rest = list_sum rest in  (*Recursive call*)
		let ans = first + sum_rest in 
		ans
;;