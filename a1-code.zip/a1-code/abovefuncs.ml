let array_above thresh arr =
	let len = Array.length arr in
	let new_len = ref 0 in
	for i=0 to len-1 do 							(*Loops through to calc length for new array*)
		if thresh > arr.(i) then begin
			new_len := !new_len + 1;
		end
	done;
	let new_arr = Array.make !new_len thresh in		
	let cur = ref 0 in
	for i=0 to len-1 do 							(*iterates through arr and adds appropriate items to new array*)
		if thresh > arr.(i) then begin
			new_arr.(!cur) <- arr.(i); 
			cur := !cur + 1;
		end
	done;
	new_arr
;;

let rec list_above thresh lst = 
	if lst = [] then
			