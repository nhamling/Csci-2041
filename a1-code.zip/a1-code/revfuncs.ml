let array_rev arr = 
	let len = Array.length arr in
	let al = len-1 in 					(*Adjusted length for looping*)
	let first = ref 0 in
	let last = ref al in
	while !first < !last do 
		let el = arr.(!first) in		(*Creates temp for first element in array*)
		arr.(!first) <- arr.(!last);	(*swaps first and last element of array*)
		arr.(!last) <- el;
		first := !first + 1;			(*increments the first element and decriments the last*)
		last := !first - 1;
	done;
	()
;;
